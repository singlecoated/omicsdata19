# Binary paths...
sambamba='/software/sambamba'
star='/software/STAR_2.3.0e/STAR'
samtools='/software/samtools-0.1.19/samtools' # deprecated...
igvtools='/Volumes/biostats/soft/IGVTools2/igvtools' # java scripts can be executed from here, platform independently

# Genome path
dm3='/Volumes/biostats/databases/STAR_genomes/dm3'
genomeigv='dm3'

# In and out paths
indir='/Volumes/biostats/oreina/class5/fastq'
outdir='/Volumes/biostats/oreina/class5/bam_STAR'

# Make output dir
mkdir $outdir

# Align and convert
for file in $indir/*.fastq
do {

# fout
fout="${file##*/}"

# Align with STAR
echo 'Aligning ' $file 'with STAR...'
$star --genomeDir $dm3 --readFilesIn $file --runThreadN 4 --outFileNamePrefix $outdir/$fout.

cd $outdir
fout=$fout.Aligned.out

# Sambamba SAM to BAM and sort
echo 'Binarizing, sorting and indexing aligned output...'	
$sambamba view  -S -f bam -t 4 -p $fout.sam -o $fout.bam
$sambamba sort -t 4 -p $fout.bam

# make tdf
$igvtools count -z 7 -w 25 -e 0 $fout.sorted.bam $fout.sorted.bam.tdf $genomeigv

cd ..

} done
