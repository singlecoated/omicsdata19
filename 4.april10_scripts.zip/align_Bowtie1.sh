#!/bin/sh
bowtie='/software/bowtie-0.12.9/bowtie'
samtools='/software/samtools-1.3/samtools'
igvtools='/software/IGVTools/igvtools'
fastqc='/software/FastQC_011/fastqc'
sambamba='/software/sambamba'

# dirs
fastqdir='/Volumes/biostats/oreina/class5/fastq'
bamdir='/Volumes/biostats/oreina/class5/bam_Bowtie1'

# igv genome
genomeigv='dm3'

# unzip and mkdir
mkdir $bamdir
cd $fastqdir
#gunzip *fastq.gz

for file in *.fastq
do {
   # Align and output as SAM
   $bowtie --sam -n 2 -p 4 -m 1 --phred33-quals /Volumes/biostats/databases/bowtie-0.12.5_indexes/d_melanogaster ./$file $bamdir/$file.m1.sam --un $bamdir/$file.un.m1.fq --max $bamdir/$file.multi1.fq

   cd $bamdir

   # sambamba SAM to BAM and sort/index
   $sambamba view  -S -f bam -t 4 -p $file.m1.sam -o $file.m1.bam
   $sambamba sort -t 4 -p $file.m1.bam

   # Sambamba filterdup, resort and index, i.e. our samples are chip-seq data
   $sambamba markdup -p -r -t 4 $file.m1.bam $file.m1.filterdup.bam
   $sambamba sort -t 4 -p $file.m1.filterdup.bam
   $sambamba index -t 4 -p $file.m1.filterdup.sorted.bam
   #rm *.sam

   # make tdf of normal and filterdup files
   $igvtools count -z 7 -w 25 -e 0 $file.m1.sorted.bam $file.m1.sorted.bam.tdf $genomeigv
   $igvtools count -z 7 -w 25 -e 0 $file.m1.filterdup.sorted.bam $file.m1.filterdup.bam.sorted.tdf $genomeigv

   # back
   cd $fastqdir

} done

# Compress unaligned fq files
#cd $fastqdir
#gzip *.fastq
