mkdir fastq
cd fastq
wget https://zenodo.org/record/61771/files/GSM461176_untreat_single_subset.fastq
wget https://zenodo.org/record/61771/files/GSM461179_treat_single_subset.fastq
